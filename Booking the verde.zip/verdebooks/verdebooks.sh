/home/ubuntu/anaconda3/envs/verdebooks/bin/python3 ./verdebooks.py
