from distutils.log import debug
from flask import Flask, render_template, request, redirect, url_for, session, make_response
from flask_socketio import SocketIO, join_room, leave_room, emit
from flask_session import Session
from datetime import datetime
import mysql.connector as mysql
from flask import jsonify
from flask_cors import CORS
from datetime import datetime,timedelta
from datetime import timedelta
from datetime import date
import random
import pdfkit
import mimerender
import imgkit
from gevent.pywsgi import WSGIServer
from openpyxl import Workbook
import pandas as pd
import pdfkit
import shutil
import openpyxl
import convertapi
from openpyxl.styles import Color, PatternFill, Font, Border
import pdfcrowd
import random
from openpyxl.styles import Alignment

app = Flask(__name__)
app.debug = True
app.config['SECRET_KEY'] = 'secret123123'
app.config['SESSION_TYPE'] = 'filesystem'

db_name = "verdebooks"
db_password = "sohaib023612"
db_user = "verdebook"
db_host = "Localhost"

# SETUP HEADERS

CORS(app)

# DATABASE INITIALIZATION

def database():
    db = mysql.connect(host=db_host, user=db_user, passwd=db_password, database=db_name)
    cursor=db.cursor(buffered=True)
    return db,cursor

# RUN PAYROLL

def calculate(values):
    record={}
    RegCurrent=values["payRate"]*values["regHours"]
    record["RegCurrent"]=RegCurrent
    YTD=RegCurrent+values["YTDPrev"]
    record["YTD"]=YTD
    OTHours=values["OTHours"]
    record["OTHours"]=OTHours
    OTRate=values["payRate"]*1.5
    record["OTRate"]=OTRate
    OTCurrent=values["OTHours"]*OTRate
    record["OTCurrent"]=OTCurrent
    OTYTD=OTCurrent+values["OTYTDPrev"]
    record["OTYTD"]=OTYTD
    VACCurrent=(RegCurrent+OTCurrent+values["stat"])*0.04
    record["VACCurrent"]=VACCurrent
    VACYTD=VACCurrent+values["VACYTDPrev"]
    record["VACYTD"]=VACYTD
    StatHours=values["stat"]
    record["StatHours"]=StatHours
    StatRate=values["statRate"]
    record["StatRate"]=StatRate
    StatCurrent=values["stat"]+values["payRate"]
    record["StatCurrent"]=StatCurrent
    StatYTD=StatCurrent+values["StatYTDPrev"]
    record["StatYTD"]=StatYTD
    IncomeTax=(RegCurrent+OTCurrent+VACCurrent+StatCurrent)*0.0505
    record["IncomeTax"]=IncomeTax
    IncomeTaxYTD=IncomeTax+values["IncomeTaxYTDPrev"]
    record["IncomeTaxYTD"]=IncomeTaxYTD
    EI=(RegCurrent+OTCurrent+VACCurrent+StatCurrent)*0.0158
    record["EI"]=EI
    EIYTD=EI+values["EIYTDPrev"]
    record["EIYTD"]=EIYTD
    CPP=(RegCurrent+OTCurrent+VACCurrent+StatCurrent)*0.0545
    record["CPP"]=CPP
    CPPYTD=CPP+values["CPPYTDPrev"]
    record["CPPYTD"]=CPPYTD
    TotalPayCurrent=RegCurrent+OTCurrent+VACCurrent+StatCurrent
    record["TotalPayCurrent"]=TotalPayCurrent
    TotalPayYTD=TotalPayCurrent+values["TotalPayYTDPrev"]
    record["TotalPayYTD"]=TotalPayYTD
    TotalTaxCurrent=IncomeTax+EI+CPP
    record["TotalTaxCurrent"]=TotalTaxCurrent
    TotalTaxYTD=TotalTaxCurrent+values["TotalTaxYTDPrev"]
    record["TotalTaxYTD"]=TotalTaxYTD
    NetPay=TotalPayCurrent-TotalTaxCurrent
    record["NetPay"]=NetPay
    return record

@app.route("/api/runPayRoll",methods=["GET","POST"])
def runPayRoll():
    db,cursor=database()
    data=request.form
    print(data)
    employees=data["employees"]
    employees=employees.split(",")
    print("employees",employees)
    regularPayHours=data["payHours"]
    regularPayHours=regularPayHours.split(",")
    print('regularPayHours',regularPayHours)
    otHours=data["otHours"]
    otHours=otHours.split(",")
    print('otHours',otHours)
    stat=data["stat"]
    stat=stat.split(",")
    print('stat',stat)
    memo=data["memo"]
    memo=memo.split(",")
    print('memo',memo)
    payDate=data["payDate"]
    week=data["week"]
    week=week.split(" - ")
    print('week',week)
    generateDate=str(datetime.today().strftime('%Y-%m-%d'))
    for i in range(len(employees)):
        query="select id from stubs where employeeId=%s and weekStart=%s and weekEnd=%s"
        values=(employees[i],week[0],week[1])
        cursor.execute(query,values)
        result=cursor.fetchall()
        if result:pass
        else:
            query1="select YTD,OTHours,OTYTD,VACYTD,StatYTD,EIYTD,CPPYTD,IncomeTaxYTD,TotalTaxYTD,TotalPayYTD,StatHours,StatRate from stubs where employeeId=%s order by id desc limit 1"
            cursor.execute(query1,(employees[i],))
            result1=cursor.fetchone()
            print("result1",result1)
            if result1:
                query2="select name,payRate from employee where id=%s"
                cursor.execute(query2,(employees[i],))
                result2=cursor.fetchone()
                print(result2)
                if result2:
                    print("generating")
                    temp={"payRate":float(result2[1]),"regHours":float(regularPayHours[i]),"YTDPrev":float(result1[0]),"OTHours":float(otHours[i]),"OTYTDPrev":float(result1[2]),
                    "stat":float(stat[i]),"VACYTDPrev":float(result1[3]),"payDate":payDate,"StatYTDPrev":float(result1[4]),"IncomeTaxYTDPrev":float(result1[7]),"EIYTDPrev":float(result1[5]),
                    "CPPYTDPrev":float(result1[6]),"TotalTaxYTDPrev":float(result1[8]),"TotalPayYTDPrev":float(result1[9]),"statRate":float(result1[10])}
                    record=calculate(temp)
                    record["name"]=result2[0]
                    record["employeeId"]=employees[0]
                    query3="insert into stubs(`generateDate`, `payDate`, `name`, `RegCurrent`, `YTD`, `OTHours`, `OTRate`, `OTCurrent`, `OTYTD`, `VACCurrent`, `VACYTD`, `StatHours`, `StatRate`, `StatYTD`, `IncomeTax`, `IncomeTaxYTD`, `EI`, `EIYTD`, `CPP`, `CPPYTD`, `TotalPayCurrent`, `TotalPayYTD`, `TotalTaxCurrent`, `TotalTaxYTD`, `NetPay`, `employeeId`, `status`,`weekStart`,`weekEnd`,`regHours`)  value(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
                    values3=(generateDate, payDate, result2[0], record["RegCurrent"], record["YTD"], record["OTHours"], record["OTRate"], record["OTCurrent"], record["OTYTD"], record["VACCurrent"],
                    record["VACYTD"], record["StatHours"], record["StatRate"], record["StatYTD"], record["IncomeTax"], record["IncomeTaxYTD"], record["EI"], record["EIYTD"], record["EIYTD"],
                    record["CPPYTD"], record["TotalPayCurrent"], record["TotalPayYTD"], record["TotalTaxCurrent"],record["TotalTaxYTD"], record["NetPay"], employees[i], "original",week[0],week[1],regularPayHours[i])
                    cursor.execute(query3,values3)
                    db.commit()
                    query6="select balance from transactionalHistory order by id desc limit 1"
                    cursor.execute(query6)
                    result6=cursor.fetchone()
                    balance=0
                    if result6:
                        balance=result6[0]
                    currentBalance=float(balance)-float(record["NetPay"])
                    if currentBalance < 0:
                        description="DEPOSIT HAMILTON nextON 93310 490 next47943523 MB-DEP"
                        query8="insert into transactionalHistory(date,description,withdrawal,deposite,balance) values(%s,%s,%s,%s,%s)"
                        payDate=datetime.strptime(payDate,'%Y-%m-%d')
                        depositeDate = payDate - timedelta(days=2)
                        cursor.execute(query8,(str(depositeDate),description,"","30000",str(float(balance)+30000)))
                        db.commit()
                        currentBalance=currentBalance+30000
                    else:pass
                    descriptions=["MISC PAYMENT nextTRANSFERWISE nextCANADA_____562D","ACCOUNTS PAYABLE nextTRAN FEE nextINTUIT CANADA U","ACCOUNTS PAYABLE next000001016983283 nextMAVERICK MACHINE nextAND HYDRAULI","ACCOUNTS PAYABLE next000001016983283 MAVERICK nextMACHINE AND nextHYDRAULI 1,178.36 32,648.93 next03/01/2022 ACCOUNTS P","ACCOUNTS PAYABLE nextDEPOSIT INTUIT nextCANADA U","BALANCE FORWARD","SERVICE CHARGE nextSCOTIA DIRECT nextPAYMENT","SD SETTLEMENT nextSD# 10460 nextFCN 0098 nextFCD 220303","BILL PAYMENT nextTXNFEE 1*$2 nextGOVERNMENT TAX nextPAYMENTS","ACCOUNTS PAYABLE nextTRAILERMASTER F","SD SETTLEMENT nextSD# 10460 FCN next0099 FCD 220304","ACCOUNTS PAYABLE nextTRAN FEE INTUIT nextCANADA U","SERVICE CHARGE","PAYROLL DEP. nextPYR WELD O nextCANADA INC","PAYROLL DEP. nextPYR WELD O nextCANADA INC"]
                    selectedDes=random.randint(0,len(descriptions)-1)
                    query5="insert into transactionalHistory(date,description,withdrawal,deposite,balance) values(%s,%s,%s,%s,%s)"
                    values5=(str(payDate),descriptions[selectedDes],str(record["NetPay"]),"",str(currentBalance))
                    cursor.execute(query5,values5)
                    db.commit()
    response=[]
    for i in range(len(employees)):
        query="select * from stubs where employeeId=%s and weekStart=%s and weekEnd=%s"
        values=(employees[i],week[0],week[1])
        cursor.execute(query,values)
        result=cursor.fetchone()
        if result:
            columns=("id", "generateDate", "payDate", "name", "RegCurrent", "YTD", "OTHours", "OTRate", "OTCurrent", "OTYTD", "VACCurrent", "VACYTD", "StatHours", "StatRate", "StatYTD", "IncomeTax", "IncomeTaxYTD", "EI", "EIYTD", "CPP", "CPPYTD", "TotalPayCurrent", "TotalPayYTD", "TotalTaxCurrent", "TotalTaxYTD", "NetPay", "employeeId", "status", "weekStart", "weekEnd", "regHours")
            temp={}
            for j in range(len(columns)):
                if j>0:
                    try:temp[columns[j]]="{:.2f}".format(float(result[j]))
                    except:temp[columns[j]]=result[j]
                else:temp[columns[j]]=result[j]
            response.append(temp)
    return jsonify({"response":response})

#  FETCH EMPLOYEES

@app.route("/api/allEmployees",methods=['GET','POST'])
def allEmployees():
    db,cursor=database()
    query="select id,paymentMethod,name,payRate from employee"
    cursor.execute(query)
    result=cursor.fetchall()
    response=[]
    for row in result:
        temp={"id":row[0],"paymentMethod":row[1],"name":row[2],"payRate":row[3]}
        response.append(temp)
    return jsonify({"response":response})

# ADD EMPLOYEE

@app.route("/api/addEmployee",methods=["GET","POST"])
def addEmployee():
    db,cursor=database()
    data=request.form
    query="INSERT INTO `employee`(`name`, `jobTitle`, `status`, `hireDate`, `dob`, `workingLocation`, `accountHolder`,`bankName`, `accountNumber`, `branchName`, `bankLocation`, `address`, `town`, `postalCode`, `phn`, `phn2`, `gender`, `notes`, `mi`, `payRate`, `payType`, `vacPolicy`, `deduction`, `paymentMethod`, `email`)  VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
    values=( data["name"], data["jobTitle"], data["status"], data["hireDate"], data["dob"], data["workingLocation"], data["accountHolder"],data["bankName"],data["accountNumber"], data["branchName"], data["bankLocation"], data["address"], data["town"], data["postalCode"], data["phn"], data["phn2"],data["gender"], data["notes"], data["mi"], data["payRate"], data["payType"], data["vacPolicy"], data["deduction"], data["paymentMethod"], data["email"])
    cursor.execute(query,values)
    db.commit()
    query3="select id from employee order by id desc limit 1"
    cursor.execute(query3)
    result3=cursor.fetchone()
    query2="insert into stubs(`generateDate`, `payDate`, `name`, `RegCurrent`, `YTD`, `OTHours`, `OTRate`, `OTCurrent`, `OTYTD`, `VACCurrent`, `VACYTD`, `StatHours`, `StatRate`, `StatYTD`, `IncomeTax`, `IncomeTaxYTD`, `EI`, `EIYTD`, `CPP`, `CPPYTD`, `TotalPayCurrent`, `TotalPayYTD`, `TotalTaxCurrent`, `TotalTaxYTD`, `NetPay`, `employeeId`, `status`,`weekStart`,`weekEnd`,`regHours`)  value(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
    generateDate=str(datetime.today().strftime('%Y-%m-%d'))
    values2=(generateDate,0,data["name"],0,0,0,0,0,0,0,0,0,1.5,0,0,0,0,0,0,0,0,0,0,0,0,result3[0],'initial',0,0,0)
    cursor.execute(query2,values2)
    db.commit()
    return jsonify({"response":"done"})

# FETCH CHEQUE

@app.route("/api/employeeStubList/<data>", methods=["GET","POST"])
def employeeChequeList(data):
    db,cursor=database()
    query="select payDate,name,NetPay,id from stubs where employeeId=%s"
    value=(data,)
    cursor.execute(query,value)
    result=cursor.fetchall()
    response=[]
    for row in result:
        if row[0]==0 or row[0]=="0":pass
        else:
            temp={"payDate":row[0],"name":row[1],"totalPay":"{:.2f}".format(float(row[2])),"netPay":"{:.2f}".format(float(row[2])),"paymentMethod":"bank","id":row[3]}
            response.append(temp)
    return jsonify({"response":response})

# FETCH EMPLOYEE DETAIL

@app.route("/api/employeeProfile/<data>",methods=["GET","POST"])
def employeeProfile(data):
    db,cursor=database()
    query="select * from employee where id=%s"
    cursor.execute(query,(data,))
    result=cursor.fetchone()
    print(len(result))
    print(result)
    response={"name":result[1],"jobTitle":result[2],"status":result[3],"hireDate":result[4],"dob":result[5],"workingLocation":result[6],"accountHolder":result[7],"bankName":result[8],"accountNumber":result[9],"branchName":result[10]
    ,"bankLocation":result[11],"address":result[12],"town":result[13],"postalCode":result[14],"phn":result[15],"phn2":result[16],"gender":result[17],"notes":result[18],"mi":result[19],"payRate":result[20],"payType":result[21],
    "vacPolicy":result[22],"deduction":result[23],"paymentMethod":result[24],"email":result[25]}
    return jsonify({"response":response})

# FETCH DATES

def numOfDays(date1, date2):
    return (date2-date1).days

@app.route("/api/getDates/<year>",methods=["GET","POST"])
def getDates(year):
    # Driver program
    start_date = date(2000,1,7)
    date2 = date.today()
    print(date2.year)
    days=numOfDays(start_date, date2)
    print(days)
    days=int(days/7)
    print(days)
    start_date=str(start_date)
    start_date=datetime.strptime(start_date, "%Y-%m-%d").strftime("%Y-%m-%d")
    fridays=[]
    dateRanges=[]
    count=0
    for i in range(days):
        previous=str(datetime.strptime(start_date, "%Y-%m-%d")+timedelta(days=1))
        friday=datetime.strptime(start_date, "%Y-%m-%d")+timedelta(days=7)
        generatedDate=str(friday)
        generatedDate=generatedDate[0:10]
        friday=datetime.strptime(str(friday.date()), "%Y-%m-%d").strftime("%Y-%m-%d")
        start_date=friday
        dateRange=previous[0:10] +" - " + str(generatedDate)
        if dateRange=="":
            pass
        else:
            if year in str(generatedDate):
                fridays.append(str(generatedDate))
                dateRanges.append(dateRange)
                count=count+1
    print(fridays)
    print(dateRanges)
    return jsonify({"dateRanges":dateRanges,"count":count})

# LOGIN

@app.route("/api/login",methods=["GET","POST"])
def login():
    db,cursor=database()
    data=request.form
    query="select id,password from usersData where email=%s"
    cursor.execute(query,(data["email"],))
    result=cursor.fetchone()
    response=""
    if result:
        if result[1]==data["password"]:
            response="Success"
        else:
            response="Invalid Password"
    else:
        response="Invalid Email or Password"
    return jsonify({"response":response})

# PRINT STUB

@app.route("/api/printStub/<data>",methods=["GET","POST"])
def printStub(data):
    db,cursor=database()
    query="select name,weekEnd,weekStart,payDate,NetPay,RegCurrent,RegCurrent,VACCurrent,VACYTD,statRate,TotalTaxCurrent,TotalTaxYTD,NetPay,TotalPayYTD,EI,EIYTD,CPP,CPPYTD,employeeId,YTD,StatYTD,IncomeTax,IncomeTaxYTD,regHours from stubs where id=%s"
    cursor.execute(query,(data,))
    result=cursor.fetchone()
    if result:
        query2="select address,town,payRate from employee where id=%s"
        cursor.execute(query2,(result[18],))
        result2=cursor.fetchone()
        sendData=[result[0],result[0],result2[0],result2[0],result2[1],result2[1],result[1],result[2],"PAY DATE: "+str(result[3]),result[3],"{:.2f}".format(float(result[4])),
        "$"+str(result[4]),"$"+str(result[4]),str(result[5]),str(result[6])+"",str(result[6])+"",str(result[6])+"",str(result[7]),str(result[8])+"",str(result[9])+"   "+str(result[9]),str(result[9])+"",
        "{:.2f}".format(float(result[10])),"{:.2f}".format(float(result[11])),"{:.2f}".format(float(result[12])),"{:.2f}".format(float(result[13])),str("{:.2f}".format(float(result[14]))),
        "{:.2f}".format(float(result[15])),"{:.2f}".format(float(result[16])),"{:.2f}".format(float(result[17])),result2[2]+".00 "+result2[2]+".00",result[19],result[20],"{:.2f}".format(float(result[21])),"{:.2f}".format(float(result[22])),result[23]]
        print(sendData)
        return render_template("generateSlip.html",data=sendData)
    else:
        return jsonify({"response":"Invalid Id"})

# TRANSACTIONAL HISTORY

@app.route("/api/transactionalHistory",methods=["GET","POST"])
def transactionalHistory():
    db,cursor=database()
    query="select id,date,description,deposite,balance from transactionalHistory"
    cursor.execute(query)
    result=cursor.fetchall()
    if result:
        response=[]
        for row in result:
            temp={"id":row[0],"date":row[1],"description":row[2],"deposite":row[3],"balance":row[4]}
            response.append(temp)
        return jsonify({"response":response})
    else:
        return jsonify({"response":"No Data Found"})

# GENERATE STATEMENT

@app.route("/api/generateStatement/<month>/<year>",methods=["GET","POST"])
def generateStatement(month,year):
    tempMonth=int(month)
    if tempMonth<10:
        tempMonth="0"+str(tempMonth)
    month=int(month)
    print(tempMonth)
    shutil.copy("/home/ubuntu/verdebooks/main.xlsx", "/home/ubuntu/verdebooks/webapp/statements/"+str(month)+"-"+str(year)+".xlsx")
    db,cursor=database()
    query="select * from transactionalHistory where date LIKE '%"+str(year)+"-"+str(month)+"%' OR date LIKE '%"+str(year)+"-"+str(tempMonth)+"%'"
    cursor.execute(query)
    result=cursor.fetchall()
    print(result)
    xfile = openpyxl.load_workbook("/home/ubuntu/verdebooks/webapp/statements/"+str(month)+"-"+str(year)+".xlsx")
    sheet = xfile.get_sheet_by_name('Sheet1')
    img = openpyxl.drawing.image.Image('logo.png')
    sheet.add_image(img,'A1')
    cur=23
    noOfDebit=0
    noOfCredit=0
    debitTotal=0
    creditTotal=0
    greyFill = PatternFill(start_color='D3D3D3',end_color='D3D3D3',fill_type='solid')
    count=0
    balance=0
    align = Alignment(horizontal='left', vertical='top', wrap_text=True)
    for row in result:
        sheet['A'+str(cur)].alignment = align
        sheet['B'+str(cur)].alignment = align
        sheet['C'+str(cur)].alignment = align
        sheet['E'+str(cur)].alignment = Alignment(horizontal='right', vertical='top', wrap_text=True)
        sheet['H'+str(cur)].alignment = Alignment(horizontal='left', vertical='top', wrap_text=True)
        sheet['I'+str(cur)].alignment = align
        sheet.column_dimensions['B'].width=13
        sheet.column_dimensions['C'].width=1
        sheet['A'+str(cur)] = row[1][0:10]
        temp = row[2].replace("next","\n")
        try:sheet['B'+str(cur)] = temp
        except:sheet['B'+str(cur)] = temp
        #sheet.merge_cells("B"+str(cur)+":"+"C"+str(cur))
        #sheet['C'+str(cur)].alignment = align
        try:sheet['E'+str(cur)] = "{:.2f}".format(float(row[3]))
        except:sheet['E'+str(cur)] = row[3]
        try:sheet['H'+str(cur)] = "{:.2f}".format(float(row[4]))
        except:sheet['H'+str(cur)] = row[4]
        try:sheet['I'+str(cur)] = "{:.2f}".format(float(row[5]))
        except:sheet['I'+str(cur)] = row[5]
        if row[3]!="":
            debitTotal=debitTotal+float(row[3])
            noOfDebit=noOfDebit+1
        if row[4]!="":
            creditTotal=creditTotal+float(row[4])
            noOfCredit=noOfCredit+1
        if count%2==0:
            sheet['A'+str(cur)].fill = greyFill
            sheet['B'+str(cur)].fill = greyFill
            sheet['C'+str(cur)].fill = greyFill
            sheet['D'+str(cur)].fill = greyFill
            sheet['E'+str(cur)].fill = greyFill
            sheet['F'+str(cur)].fill = greyFill
            sheet['G'+str(cur)].fill = greyFill
            sheet['H'+str(cur)].fill = greyFill
            sheet['I'+str(cur)].fill = greyFill
        try:balance = "{:.2f}".format(float(row[5]))
        except:balance = row[5]
        cur=cur+2
        count=count+1;
    sheet['A18']=noOfDebit
    sheet['E18']=noOfCredit
    sheet['B18']="$"+str("{:.2f}".format(float(balance)))
    sheet['G18']="$"+str("{:.2f}".format(creditTotal))
    previousMonth=int(month)-1
    temp=year
    if month==1:
       previousMonth=12
       temp=int(year)-1
    sheet['F13'] = str(previousMonth)+"-"+str(temp)
    sheet['H13']=str(month)+"-"+str(year)
    xfile.save("/home/ubuntu/verdebooks/webapp/statements/"+str(month)+"-"+str(year)+".xlsx")
    #SaveFormat = self.SaveFormat
    #workbook = Workbook("Book1.xlsx")
    #workbook.save("1.pdf", SaveFormat.PDF)
    #df = pd.read_excel("/home/ubuntu/verdebooks/trail2.xlsx")
    #df.to_html("trail2.html")
    #pdfkit.from_file("trail2.html", "trail2.pdf")
    url="https://verdebooks.com/statements/"+str(month)+"-"+str(year)+".pdf"
    convertapi.api_secret = 'yAJaATqhPEgmZuBh'
    convertapi.convert('pdf', {'File': '/home/ubuntu/verdebooks/webapp/statements/'+str(month)+'-'+str(year)+'.xlsx'}, from_format = 'xlsx').save_files('/home/ubuntu/verdebooks/webapp/statements/'+str(month)+'-'+str(year)+'.pdf')
    return jsonify({"response":url})

# Transactional Records

@app.route("/api/transactionalHistoryAll",methods=["GET","POST"])
def transactionalHistoryAll():
    db,cursor=database()
    query="select id,date,description,withdrawal,deposite,balance from transactionalHistory"
    cursor.execute(query)
    result=cursor.fetchall()
    response=[]
    if result:
        for row in result:
            try:withdraw="{:.2f}".format(float(row[3]))
            except:withdraw=row[3]
            try:deposite="{:.2f}".format(float(row[4]))
            except:deposite=row[4]
            try:balance="{:.2f}".format(float(row[5]))
            except:balance=row[5]
            dateTemp=row[1]
            temp={"id":row[0],"date":dateTemp[0:10],"description":row[2],"withdrawal":withdraw,"deposite":deposite,"balance":balance}
            response.append(temp)
    return jsonify({"response":response})

#Current Balance

@app.route("/api/currentBalance",methods=["GET","POST"])
def currentBalance():
    db,cursor=database()
    query="select balance from transactionalHistory order by id desc limit 1"
    cursor.execute(query)
    result=cursor.fetchone()
    balance="{:.2f}".format(float(result[0]))
    return jsonify({"balance":balance})


@app.route("/api/addBalance",methods=["GET","POST"])
def addBalance():
    data=request.form
    db,cursor=database()
    query="select balance,id from transactionalHistory order by id desc limit 1"
    cursor.execute(query)
    result=cursor.fetchone()
    currentBalance=float(result[0])
    newBalance=currentBalance+float(data["balance"])
    description="DEPOSIT HAMILTON nextON 93310 490 next47943523 MB-DEP"
    query2="insert into transactionalHistory(date,description,withdrawal,deposite,balance) values(%s,%s,%s,%s,%s)"
    generateDate=str(datetime.today().strftime('%Y-%m-%d'))
    values2=(generateDate,description,"",data["balance"],newBalance)
    cursor.execute(query2,values2)
    db.commit()
    return jsonify({"response":"Added Successfully"})

#URL TO PDF
@app.route("/api/urlToPdf/<data>",methods=["GET","POST"])
def urlToPdf(data):
    api = pdfcrowd.HtmlToPdfClient("sohaib", "b68af86f1879568b27d711cd29c5346f")
    api.convertUrlToFile("https://verdebooks.com:7900/api/printStub/"+data, "/home/ubuntu/verdebooks/webapp/example1.pdf")
    return jsonify({"url":"https://verdebooks.com/example1.pdf"})

#PAY CHEQUE LIST

@app.route("/api/payChequeList", methods=["GET","POST"])
def payChequeList():
    db,cursor=database()
    query="select payDate,name,NetPay,id from stubs order by id desc limit 50"
    cursor.execute(query)
    result=cursor.fetchall()
    response=[]
    for row in result:
        if row[0]==0 or row[0]=="0":pass
        else:
            temp={"payDate":row[0],"name":row[1],"totalPay":"{:.2f}".format(float(row[2])),"netPay":"{:.2f}".format(float(row[2])),"paymentMethod":"bank","id":row[3]}
            response.append(temp)
    return jsonify({"response":response})

# RUN APPLICATION

if __name__=="__main__":
    #gevent.get_hub().SYSTEM_ERROR = BaseException
    app.secret_key="Infiniti123"
    #context=('cert.crt','privkey.key')
    #app.run(port=7900, debug=True, host='0.0.0.0', ssl_context=context, threaded=True)
    http_server = WSGIServer(('0.0.0.0', 7900), app,certfile="cert.crt",keyfile="privkey.key")
    #http_server = WSGIServer(('', 7900),app)
    http_server.serve_forever()
